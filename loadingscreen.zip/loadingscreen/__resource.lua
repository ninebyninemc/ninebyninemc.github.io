files {
    'index.html',
    'css/normalize.css',
    'css/style.css',
    'images/divider.png',
    'images/pattern.png',
    'css/Wisdom.otf',
    'js/custom.js',
    'js/device.min.js',
    'js/jquery.mb.YTPlayer.js',
    'js/jquery-1.11.1.min.js',
}

loadscreen 'index.html'

resource_manifest_version '72431fab-63ca-442c-c67b-abc70f28dfa5'